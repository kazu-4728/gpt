# Power Automate Flow Templates

このリポジトリは、Power Automate のフローを ZIP 形式で管理・再利用するためのテンプレート集です。  
共通のテンプレート (`TEMPLATE` ディレクトリ) をコピーして GUID や条件を変更することで、新しいフローの雛形として利用できます。

## 利用方法

1. `TEMPLATE` ディレクトリをコピーし、新しい GUID を発行して `manifest.json` および `definition.json` に適用します。  
2. 仕様変更や条件の設定（日時フィルタ、部分一致キー等）を `README.md` に記載してから ZIP 化します。  
3. 作成した ZIP ファイルを Power Automate でインポートし、必要な接続を割り当てます。  
